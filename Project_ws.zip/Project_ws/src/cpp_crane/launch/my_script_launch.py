import launch
import launch_ros.actions

def generate_launch_description():
    return launch.LaunchDescription([
        # This is your existing publisher node
        launch_ros.actions.Node(
            package='cpp_crane',
            executable='cranecntrl',
            name='cranecntrl',
            output='screen'
        ),
        # The subscriber node section has been removed
    ])

