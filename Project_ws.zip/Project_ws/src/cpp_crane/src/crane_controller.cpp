#include <chrono>
#include <functional>
#include <memory>

#include "rclcpp/rclcpp.hpp"
#include "sensor_msgs/msg/joint_state.hpp"
#include "tutorial_interfaces/msg/boom_angle.hpp"
#include "std_msgs/msg/float64.hpp"

namespace crane {
    namespace config {
        using namespace std::chrono_literals;
        const auto dt = 20ms;
    }
}

class CraneReferencePublisher : public rclcpp::Node
{
public:
    CraneReferencePublisher()
    : Node("cranecntrl")
    , step_(0)
    {
        using namespace std::chrono_literals;

        publisher_ = this->create_publisher<sensor_msgs::msg::JointState>("joint_states", 5);
        timer_ = this->create_wall_timer(crane::config::dt, std::bind(&CraneReferencePublisher::update_reference, this));
        
        //subscriber of position from ads node
        subscriber_ = this->create_subscription<tutorial_interfaces::msg::BoomAngle>(
            "boom_angle", 10,
            std::bind(&CraneReferencePublisher::position_callback, this, std::placeholders::_1));
    }

private:
    void update_reference() {
        sensor_msgs::msg::JointState message;
        message.header.stamp = this->get_clock()->now();
        message.position.push_back(step_);
        message.name.push_back("base_to_crane_boom");
        RCLCPP_INFO(this->get_logger(), "Boom angle: '%f'", message.position[0]);
        publisher_->publish(message);
    }
    
    void position_callback(const tutorial_interfaces::msg::BoomAngle msg) {
        step_ = msg.boomangle;
        RCLCPP_INFO(this->get_logger(), "Received position: %f", msg.boomangle);
    }

    rclcpp::TimerBase::SharedPtr timer_;
    rclcpp::Publisher<sensor_msgs::msg::JointState>::SharedPtr publisher_;
    rclcpp::Subscription<tutorial_interfaces::msg::BoomAngle>::SharedPtr subscriber_;
    float step_;
};

int main(int argc, char *argv[])
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<CraneReferencePublisher>());
    rclcpp::shutdown();
    return 0;
}

