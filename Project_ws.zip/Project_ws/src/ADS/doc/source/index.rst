.. adstool documentation master file, created by
   copy & paste on Tue Aug 3 16:21:14 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

adstool
========

.. toctree::
   :maxdepth: 1

   adstool

