#include <iostream>
#include <string>
#include "AdsLib.h"
#include "AdsVariable.h"

#include "rclcpp/rclcpp.hpp"
#include "tutorial_interfaces/msg/controller_parameters.hpp"
#include "tutorial_interfaces/msg/boom_angle.hpp"



#include <thread>
#include <chrono>

// For ROS Communication
#include <functional>
#include <memory>

double globalBoomAngle = 0.0;
              
namespace craneads {

    struct AdsVariables
    {
        AdsVariables() = delete;

        explicit AdsVariables(AdsDevice& route)
            : activateMotion{route, "MAIN.bActivateMotion"}
            , velocityReference{route, "MAIN.fVelRef"}
            , positionReference{route, "MAIN.fPosRef"}
            
            , positionMeasurement{route, "MAIN.fPosMeas"}
            , pistonSidePressure{route, "MAIN.fPistonSidePressure"}
            , rodSidePressure{route, "MAIN.fRodSidePressure"}
            
        {
            // Do nothing.
        }

	// Send
        AdsVariable<bool> activateMotion;
        AdsVariable<double> velocityReference;
        AdsVariable<double> positionReference;
        
        // Recieve
        AdsVariable<double> positionMeasurement;
        AdsVariable<double> pistonSidePressure;
        AdsVariable<double> rodSidePressure;
    };

    class AdsHandler
    {
    public:
        explicit AdsHandler(const AmsNetId remoteNetId, const std::string remoteIpV4)
            : remoteNetId_(remoteNetId)
            , remoteIpV4_(remoteIpV4)
            , route_{remoteIpV4_, remoteNetId_, AMSPORT_R0_PLC_TC3}
            , ads_(route_) { }

        AdsHandler() : AdsHandler({127, 0, 0, 1,  1, 1}, "127.0.0.1") { }


        void activateMotion()
        {
            ads_.activateMotion = true;
        }

        void deactivateMotion()
        {
            ads_.activateMotion = false;
        }

        void setVelocityReference(double value)
        {
            ads_.velocityReference = value;
        }

        void setPositionReference(double value)
        {
            ads_.positionReference = value;
        }



        double getPositionMeasurement()
        {
            globalBoomAngle = ads_.positionMeasurement;
            return globalBoomAngle;
        }
        
         double getPistonSidePressure()
        {
            return ads_.pistonSidePressure;
        }
        
         double getRodSidePressure()
        {
            return ads_.rodSidePressure;
        }


        void printState()
        {
            const auto state = route_.GetState();
            std::cout << "ADS state: "
                      << std::dec << static_cast<uint16_t>(state.ads)
                      << " devState: "
                      << std::dec << static_cast<uint16_t>(state.device);
        }

        ~AdsHandler() { }

    private:
        const AmsNetId remoteNetId_;
        const std::string remoteIpV4_;
        AdsDevice route_;
        AdsVariables ads_;
    };

}


using std::placeholders::_1;
using namespace std::chrono_literals;


class AdsNode : public rclcpp::Node
{
public:
  AdsNode()
  : Node("ads_node"), count_(0)
  {
    publisher_ = this->create_publisher<tutorial_interfaces::msg::BoomAngle>("boom_angle", 1000);
    
    subscription_ = this->create_subscription<tutorial_interfaces::msg::ControllerParameters>(    
    "controller_parameters", 10, std::bind(&AdsNode::topic_callback, this, _1));
    
    timer_ = this->create_wall_timer(20ms, std::bind(&AdsNode::timer_callback, this));
  }

private:
  // Subscriber, read values from controller node on topic "controllerParameters"
  void topic_callback(const tutorial_interfaces::msg::ControllerParameters & msg) const 
  { 
    RCLCPP_INFO_STREAM(this->get_logger(), "I heard the int value from controller: '" << msg.n << "'");
    RCLCPP_INFO_STREAM(this->get_logger(), "I heard the startsimulation value from controller: '" << msg.startsimulation << "'");
  }
  
  void timer_callback()
  {
    auto message = tutorial_interfaces::msg::BoomAngle();                                   
    message.boomangle = globalBoomAngle; //testDouble_;                                                     
    RCLCPP_INFO_STREAM(this->get_logger(), "Publishing the Boom Angle to the CPP_CRANE read from Beckhoff ADS: '" << message.boomangle << "'");   
    publisher_->publish(message);
  }
  
  rclcpp::Subscription<tutorial_interfaces::msg::ControllerParameters>::SharedPtr subscription_;  
  rclcpp::Publisher<tutorial_interfaces::msg::BoomAngle>::SharedPtr publisher_;             
  rclcpp::TimerBase::SharedPtr timer_;
  
  size_t count_;
  double testDouble_ = 10.0;
};

void AdsCommunicationInitialize()
{
  std::cout << "Example ROS2 ADS node starting up.." << std::endl;

  // Real lab PLC IP.
  const AmsNetId remoteNetId { 192, 168, 0, 10, 1, 1 };
  const std::string remoteIpV4 = "192.168.0.10";

  std::cout << "  Create AdsHandler.. ";
  craneads::AdsHandler adsHandler(remoteNetId, remoteIpV4);
  std::cout << "  OK" << std::endl;

  //adsHandler.deactivateMotion();
  
  // Starts simulation on the PLC
  adsHandler.activateMotion();
  adsHandler.printState();
  adsHandler.setVelocityReference(3.2);
  std::this_thread::sleep_for (std::chrono::seconds(5));
  adsHandler.setPositionReference(3.14);

  while(true)
  {
    // Read Values from ADS Beckhoff
    std::cout << "Position measurement from ADS: " << adsHandler.getPositionMeasurement() << std::endl;
    std::cout << "Piston Side Pressure from ADS: " << adsHandler.getPistonSidePressure()<< std::endl;
    std::cout << "Rod Side Pressure from ADS from ADS: " << adsHandler.getRodSidePressure() << std::endl;
      
    // Time delay of 50ms to not send to fast
    std::this_thread::sleep_for (std::chrono::milliseconds(20));
  }
}

int main(int argc, char * argv[])
{

  std::thread ads_thread(AdsCommunicationInitialize);
  
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<AdsNode>());
  
  ads_thread.join();
  rclcpp::shutdown();
 // This function at the end, since it runs i a for loop	
 return 0;
}
