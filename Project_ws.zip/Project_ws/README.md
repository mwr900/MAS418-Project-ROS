terminal commands:

Terminal 1:
Start ADS Node:
source ros2_humble/install/setup.bash && 
cd Project_ws && 
colcon build && 
source install/setup.bash && 
ros2 run ads_communication ads_node

Terminal 2:
Start CPPCrane:
source ros2_humble/install/setup.bash && 
cd Project_ws && 
source install/setup.bash && 
ros2 launch cpp_crane my_script_launch.py

Terminal 3:
Start URDF / RVIZ
source ros2_humble/install/setup.bash && 
cd Project_ws && 
source install/setup.bash && 
ros2 launch urdf_tutorial display.launch.py


Does not work
_____________
Terminal 4:
Start Controller
source ros2_humble/install/setup.bash && 
cd Project_ws &&
source install/setup.bash && 
ros2 run controller controllerPublisher





